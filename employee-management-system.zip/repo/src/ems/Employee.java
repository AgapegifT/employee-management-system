package ems;

/**
 * Employee.java
 *
 * Plain data holder for one employee record: ID, name, department and
 * base salary. No validation or business logic lives here - that is all
 * in EmployeeManagementSystem, so this class stays simple and easy to
 * reuse (e.g. from a test, or from a future UI).
 */
public class Employee {

    private final String id;
    private final String name;
    private final String department;
    private final double baseSalary;

    public Employee(String id, String name, String department, double baseSalary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.baseSalary = baseSalary;
    }

    public String getId()         { return id; }
    public String getName()       { return name; }
    public String getDepartment() { return department; }
    public double getBaseSalary() { return baseSalary; }

    @Override
    public String toString() {
        return String.format("%s | %-15s | %-12s | base %.2f", id, name, department, baseSalary);
    }
}
