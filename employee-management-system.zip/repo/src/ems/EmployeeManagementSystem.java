package ems;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * EmployeeManagementSystem.java
 *
 * Implements the seven functional requirements from Section 1 of the
 * report: employee record management (FR1, FR2, FR3), payment processing
 * (FR4, FR5), payroll reporting (FR6) and the employee count (FR7).
 *
 * Everything is kept in memory in a Map, exactly like a small in-memory
 * "table" - no database or file is needed to run or test this class.
 */
public class EmployeeManagementSystem {

    /** Standard working hours in a month, used to derive the hourly rate (FR4). */
    public static final double STANDARD_HOURS = 160.0;

    /** Overtime is paid at 1.5x the derived hourly rate (Section 2.1). */
    public static final double OVERTIME_MULTIPLIER = 1.5;

    /** Employees in this department get a 10% bonus on gross pay (Section 2.1). */
    public static final String BONUS_DEPARTMENT = "Management";
    public static final double BONUS_RATE = 0.10;

    /** Gross pay at or above this amount is taxed at the higher rate (Section 2.1). */
    public static final double HIGH_INCOME_THRESHOLD = 5000.0;
    public static final double HIGH_TAX_RATE = 0.25;
    public static final double LOW_TAX_RATE = 0.15;

    // Stands in for the employees "table": key = employee ID.
    // LinkedHashMap keeps them in the order they were added, which makes
    // the employee list and the payroll report easier to read.
    private final Map<String, Employee> employees = new LinkedHashMap<>();

    // -----------------------------------------------------------------
    // FR1 / FR2 - add a new employee
    // -----------------------------------------------------------------

    /**
     * Registers a new employee.
     *
     * Validation errors (bad input) throw IllegalArgumentException, since
     * they are programming/usage mistakes the caller should fix before
     * trying again. A duplicate ID is different: it is a normal, expected
     * outcome of using the system (someone typed an ID that is already
     * taken), so it is reported by returning false instead of throwing -
     * this matches BB-02, where the second add is simply "rejected
     * (returns false)".
     *
     * @return true if the employee was added, false if the ID was already in use
     * @throws IllegalArgumentException if id or name is missing/empty, or
     *         baseSalary is negative (FR2)
     */
    public boolean addEmployee(String id, String name, String department, double baseSalary) {

        // FR2: id missing/empty -> validation error (BB-03)
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("Employee ID is required");
        }
        // FR2: name missing/empty -> validation error
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Employee name is required");
        }
        // FR2: negative base salary -> validation error (BB-04)
        if (baseSalary < 0) {
            throw new IllegalArgumentException("Base salary cannot be negative");
        }
        // Department is not validated for emptiness by FR2 - only ID and
        // name are required there - so an empty department is allowed
        // here; it simply will not qualify for the Management bonus.

        // FR2: ID already in use -> reject without throwing (BB-02)
        if (employees.containsKey(id)) {
            return false;
        }

        employees.put(id, new Employee(id, name, department, baseSalary));
        return true;
    }

    // -----------------------------------------------------------------
    // FR3 - remove an employee
    // -----------------------------------------------------------------

    /**
     * Removes an employee by ID.
     *
     * @return true if an employee with that ID existed and was removed,
     *         false if no such employee was found (BB-06) - this is a
     *         normal outcome, not an error, so no exception is thrown.
     */
    public boolean removeEmployee(String id) {
        // Map.remove() returns the removed value, or null if the key was
        // not present - which lines up neatly with true/false here.
        return employees.remove(id) != null;
    }

    // -----------------------------------------------------------------
    // FR4 / FR5 - process a payment
    // -----------------------------------------------------------------

    /**
     * Computes and returns one employee's net pay for a pay period.
     *
     * Order of checks matters here (see BB-09 vs BB-10): the hours are
     * validated FIRST, before the employee is even looked up. That is
     * why processPayment("E001", -10, 0) on an EMPTY system still throws
     * IllegalArgumentException (bad hours) rather than "employee not
     * found" - the bad input is rejected before the system ever looks
     * to see who E001 is.
     *
     * Pay calculation (Section 2.1):
     *   1. hourlyRate      = baseSalary / 160 standard hours
     *   2. overtimePay     = overtimeHours x hourlyRate x 1.5
     *   3. grossBeforeBonus= baseSalary + overtimePay
     *      (the "hours" parameter itself does not scale the base salary -
     *      an employee is paid their salary as long as they logged a
     *      non-negative number of hours; only overtime hours add extra
     *      pay on top)
     *   4. gross           = grossBeforeBonus x 1.10 if department is
     *                        "Management", otherwise grossBeforeBonus
     *   5. tax rate         = 25% if gross >= 5000, otherwise 15%
     *   6. net pay          = gross x (1 - tax rate)
     *
     * @throws IllegalArgumentException if hours or overtimeHours is negative (FR5)
     * @throws NoSuchElementException if no employee with that ID is registered (FR5)
     */
    public double processPayment(String id, double hours, double overtimeHours) {

        // FR5: negative hours or overtime -> validation error, checked
        // before anything else (BB-09).
        if (hours < 0 || overtimeHours < 0) {
            throw new IllegalArgumentException("Hours and overtime hours cannot be negative");
        }

        // FR5: unknown employee ID -> "not found" error (BB-10).
        Employee e = employees.get(id);
        if (e == null) {
            throw new NoSuchElementException("No employee registered with ID " + id);
        }

        return computeNetPay(e, overtimeHours);
    }

    /** Shared pay calculation, used by processPayment() and by the payroll report. */
    private double computeNetPay(Employee e, double overtimeHours) {
        double hourlyRate = e.getBaseSalary() / STANDARD_HOURS;
        double overtimePay = overtimeHours * hourlyRate * OVERTIME_MULTIPLIER;
        double grossBeforeBonus = e.getBaseSalary() + overtimePay;

        double gross = BONUS_DEPARTMENT.equals(e.getDepartment())
                ? grossBeforeBonus * (1 + BONUS_RATE)
                : grossBeforeBonus;

        double taxRate = gross >= HIGH_INCOME_THRESHOLD ? HIGH_TAX_RATE : LOW_TAX_RATE;
        double net = gross * (1 - taxRate);

        // Round to 2 decimal places, like real currency amounts.
        return Math.round(net * 100.0) / 100.0;
    }

    // -----------------------------------------------------------------
    // FR6 - payroll report
    // -----------------------------------------------------------------

    /**
     * Builds a printable payroll report: every employee's net pay
     * (computed at standard hours, no overtime, so the report does not
     * depend on whether processPayment() was called beforehand), the
     * total payroll, the average net pay, and the top earner.
     *
     * @return "No employees to report." if there are no employees (BB-12),
     *         otherwise the formatted report (BB-11).
     */
    public String generatePayrollReport() {
        if (employees.isEmpty()) {
            return "No employees to report.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("PAYROLL REPORT\n");

        double total = 0.0;
        Employee topEarner = null;
        double topNet = -1.0;

        for (Employee e : employees.values()) {
            double net = computeNetPay(e, 0.0); // standard pay: no overtime
            sb.append(String.format("  %-6s %-15s net pay: %.2f%n", e.getId(), e.getName(), net));
            total += net;
            if (net > topNet) {
                topNet = net;
                topEarner = e;
            }
        }

        double average = Math.round((total / employees.size()) * 100.0) / 100.0;
        total = Math.round(total * 100.0) / 100.0;

        sb.append(String.format("Total payroll: %.2f%n", total));
        sb.append(String.format("Average net pay: %.2f%n", average));
        sb.append(String.format("Top earner: %s (%s), net pay %.2f%n",
                topEarner.getName(), topEarner.getId(), topNet));
        return sb.toString();
    }

    // -----------------------------------------------------------------
    // FR7 - employee count
    // -----------------------------------------------------------------

    /** Number of employees currently registered. */
    public int count() {
        return employees.size();
    }

    /** Read-only view of one employee, or null if the ID is not registered. Handy for tests/UI. */
    public Employee find(String id) {
        return employees.get(id);
    }

    // ===================================================================
    // Interactive console menu - this is what "being a user" of the
    // system looks like. Run this class (java ems.EmployeeManagementSystem)
    // and follow the menu to add employees, remove them, process
    // payments and generate a payroll report yourself, by hand.
    // ===================================================================
    public static void main(String[] args) {
        EmployeeManagementSystem system = new EmployeeManagementSystem();
        Scanner in = new Scanner(System.in);

        while (true) {
            System.out.println();
            System.out.println("==== Employee Management System ====");
            System.out.println("1. Add employee");
            System.out.println("2. Remove employee");
            System.out.println("3. Process payment");
            System.out.println("4. Generate payroll report");
            System.out.println("5. Show employee count");
            System.out.println("6. Exit");
            System.out.print("Choose an option (1-6): ");
            String choice = in.nextLine().trim();

            try {
                switch (choice) {
                    case "1": {
                        System.out.print("Employee ID: ");
                        String id = in.nextLine();
                        System.out.print("Name: ");
                        String name = in.nextLine();
                        System.out.print("Department: ");
                        String dept = in.nextLine();
                        System.out.print("Base salary: ");
                        double salary = Double.parseDouble(in.nextLine().trim());
                        boolean added = system.addEmployee(id, name, dept, salary);
                        System.out.println(added ? "Employee added successfully."
                                : "Employee ID already exists. Please use a unique ID.");
                        break;
                    }
                    case "2": {
                        System.out.print("Employee ID to remove: ");
                        String id = in.nextLine();
                        boolean removed = system.removeEmployee(id);
                        System.out.println(removed ? "Employee removed."
                                : "No employee found with that ID.");
                        break;
                    }
                    case "3": {
                        System.out.print("Employee ID: ");
                        String id = in.nextLine();
                        System.out.print("Hours worked: ");
                        double hours = Double.parseDouble(in.nextLine().trim());
                        System.out.print("Overtime hours: ");
                        double ot = Double.parseDouble(in.nextLine().trim());
                        double net = system.processPayment(id, hours, ot);
                        System.out.printf("Net pay: %.2f%n", net);
                        break;
                    }
                    case "4":
                        System.out.print(system.generatePayrollReport());
                        break;
                    case "5":
                        System.out.println("Employees registered: " + system.count());
                        break;
                    case "6":
                        System.out.println("Goodbye.");
                        return;
                    default:
                        System.out.println("Please choose 1-6.");
                }
            } catch (IllegalArgumentException | NoSuchElementException ex) {
                // Both of the exceptions the business logic can throw are
                // caught here and shown as a normal message, instead of
                // crashing the menu - the same way a real application
                // would show a validation error to its user.
                System.out.println("Error: " + ex.getMessage());
            }
        }
    }
}
