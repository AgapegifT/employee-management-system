package ems;

import java.util.NoSuchElementException;

/**
 * EmployeeManagementSystemTest.java
 *
 * A small, dependency-free test harness: no JUnit is required, so it
 * compiles and runs with a plain "javac ems/*.java && java ems.EmployeeManagementSystemTest",
 * exactly as Section 3 of the report describes.
 *
 * Each check() call is one test case. It prints PASS or FAIL and the
 * observed value, and keeps a running count for the final summary line -
 * this is what "the JVM process ends after the test harness prints its
 * summary" (Stop Procedures) refers to.
 *
 * Test case IDs match the report: BB-01..BB-12 are the black-box cases
 * from Section 4 (same inputs, same expected results). WB-01..WB-06 are
 * new white-box cases, designed by reading the source of
 * EmployeeManagementSystem rather than the requirements text, so that
 * together the two sets exercise every branch of the class.
 */
public class EmployeeManagementSystemTest {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) {
        blackBoxTests();
        whiteBoxTests();

        System.out.println();
        System.out.println("==================================================");
        System.out.printf("TOTAL: %d passed, %d failed, %d test cases%n", passed, failed, passed + failed);
        System.out.println("==================================================");
    }

    // ===================================================================
    // Black-box tests - derived from FR1..FR7 only (Section 4 of the report)
    // ===================================================================
    private static void blackBoxTests() {
        System.out.println("---- Black-box tests ----");

        // BB-01: add a valid new employee
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            boolean added = s.addEmployee("E001", "Alice Uwase", "Engineering", 3000);
            check("BB-01", added && s.count() == 1,
                    "addEmployee returned " + added + ", count=" + s.count());
        }

        // BB-02: adding the same ID twice is rejected (returns false, not an exception)
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            s.addEmployee("E001", "Alice Uwase", "Engineering", 3000);
            boolean secondAdd = s.addEmployee("E001", "Someone Else", "HR", 4000);
            check("BB-02", !secondAdd && s.count() == 1,
                    "second addEmployee returned " + secondAdd + ", count=" + s.count());
        }

        // BB-03: empty ID -> IllegalArgumentException
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            boolean threw = false;
            try {
                s.addEmployee("", "Alice", "Engineering", 3000);
            } catch (IllegalArgumentException ex) {
                threw = true;
            }
            check("BB-03", threw, "IllegalArgumentException thrown = " + threw);
        }

        // BB-04: negative salary -> IllegalArgumentException
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            boolean threw = false;
            try {
                s.addEmployee("E001", "Alice", "Engineering", -100);
            } catch (IllegalArgumentException ex) {
                threw = true;
            }
            check("BB-04", threw, "IllegalArgumentException thrown = " + threw);
        }

        // BB-05: remove an employee that exists
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            s.addEmployee("E001", "Alice", "Engineering", 3000);
            boolean removed = s.removeEmployee("E001");
            check("BB-05", removed && s.count() == 0,
                    "removeEmployee returned " + removed + ", count=" + s.count());
        }

        // BB-06: remove an ID that does not exist
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            boolean removed = s.removeEmployee("E999");
            check("BB-06", !removed, "removeEmployee returned " + removed);
        }

        // BB-07: non-management employee below the high-income threshold
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            s.addEmployee("E001", "Alice", "Engineering", 3000);
            double net = s.processPayment("E001", 160, 0);
            check("BB-07", net == 2550.00, "net pay = " + net + " (expected 2550.00)");
        }

        // BB-08: management employee reaching the high-income threshold
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            s.addEmployee("E001", "Bob", "Management", 6000);
            double net = s.processPayment("E001", 160, 0);
            check("BB-08", net == 4950.00, "net pay = " + net + " (expected 4950.00)");
        }

        // BB-09: negative hours -> IllegalArgumentException (checked before employee lookup)
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            boolean threw = false;
            try {
                s.processPayment("E001", -10, 0);
            } catch (IllegalArgumentException ex) {
                threw = true;
            }
            check("BB-09", threw, "IllegalArgumentException thrown = " + threw);
        }

        // BB-10: unregistered employee ID -> NoSuchElementException
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            boolean threw = false;
            try {
                s.processPayment("E999", 160, 0);
            } catch (NoSuchElementException ex) {
                threw = true;
            }
            check("BB-10", threw, "NoSuchElementException thrown = " + threw);
        }

        // BB-11: payroll report with employees registered
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            s.addEmployee("E001", "Alice", "Engineering", 3000);
            s.processPayment("E001", 160, 0);
            String report = s.generatePayrollReport();
            boolean ok = report.contains("Alice") && report.contains("Total payroll")
                    && report.contains("Average net pay") && report.contains("Top earner");
            check("BB-11", ok, "report =\n" + indent(report));
        }

        // BB-12: payroll report with no employees
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            String report = s.generatePayrollReport();
            check("BB-12", report.equals("No employees to report."), "report = \"" + report + "\"");
        }
    }

    // ===================================================================
    // White-box tests - each one forces a specific branch in
    // EmployeeManagementSystem.java that the black-box cases above do
    // not reach, referenced by the rule it exercises.
    // ===================================================================
    private static void whiteBoxTests() {
        System.out.println();
        System.out.println("---- White-box tests ----");

        // WB-01: empty employee name -> IllegalArgumentException
        // (branch: `name == null || name.trim().isEmpty()`, not covered by any BB case)
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            boolean threw = false;
            try {
                s.addEmployee("E001", "  ", "Engineering", 3000);
            } catch (IllegalArgumentException ex) {
                threw = true;
            }
            check("WB-01", threw, "IllegalArgumentException thrown = " + threw);
        }

        // WB-02: base salary of exactly 0 is accepted (boundary of the "negative" check)
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            boolean added = s.addEmployee("E001", "Alice", "Engineering", 0);
            check("WB-02", added, "addEmployee(salary=0) returned " + added);
        }

        // WB-03: gross pay of exactly 5000.00 falls in the HIGH tax bracket
        // (branch: `gross >= HIGH_INCOME_THRESHOLD`, TRUE at the boundary itself)
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            s.addEmployee("E001", "Alice", "Engineering", 5000);
            double net = s.processPayment("E001", 160, 0);
            // gross = 5000 (no bonus); tax = 25% since gross >= 5000; net = 5000 * 0.75 = 3750.00
            check("WB-03", net == 3750.00, "net pay = " + net + " (expected 3750.00)");
        }

        // WB-04: overtime pay for a non-management employee
        // (branch: overtimeHours > 0, exercises the overtime formula on its own)
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            s.addEmployee("E001", "Alice", "Engineering", 1600); // hourly rate = 1600/160 = 10.00
            double net = s.processPayment("E001", 160, 10);
            // overtime pay = 10 * 10.00 * 1.5 = 150.00; gross = 1750.00 (< 5000, no bonus)
            // net = 1750.00 * 0.85 = 1487.50
            check("WB-04", net == 1487.50, "net pay = " + net + " (expected 1487.50)");
        }

        // WB-05: management bonus combined with overtime, still below the high-income threshold
        // (branch: department == "Management" TRUE, gross >= 5000 FALSE)
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            s.addEmployee("E001", "Carol", "Management", 2000); // hourly rate = 12.50
            double net = s.processPayment("E001", 160, 4);
            // overtime pay = 4 * 12.50 * 1.5 = 75.00; grossBeforeBonus = 2075.00
            // gross = 2075.00 * 1.10 = 2282.50 (< 5000, low tax rate)
            // net = 2282.50 * 0.85 = 1940.125 -> rounded to 1940.13 (Java rounds half up)
            check("WB-05", net == 1940.13, "net pay = " + net + " (expected 1940.13)");
        }

        // WB-06: payroll report picks the correct top earner among several employees
        // (branch: `net > topNet` becoming true more than once in the loop)
        {
            EmployeeManagementSystem s = new EmployeeManagementSystem();
            s.addEmployee("E001", "Alice", "Engineering", 3000);  // net 2550.00
            s.addEmployee("E002", "Bob", "Management", 6000);     // net 4950.00 (highest)
            s.addEmployee("E003", "Carol", "Engineering", 2000);  // net 1700.00
            String report = s.generatePayrollReport();
            boolean ok = report.contains("Top earner: Bob");
            check("WB-06", ok, "report =\n" + indent(report));
        }
    }

    // ---- tiny assertion helper -----------------------------------------
    private static void check(String id, boolean pass, String detail) {
        System.out.println((pass ? "[OK] " : "[FAIL] ") + id + " - " + detail);
        if (pass) passed++; else failed++;
    }

    private static String indent(String s) {
        return "    " + s.replace("\n", "\n    ");
    }
}
